package br.com.tt.petshop.model;

public class Procedimento {
    private String procedimento;
    private Produto produto;
}
