package br.com.tt.petshop.model;

public class Unidade {
}
