package br.com.tt.petshop.enums;

public enum EspecieEnum {
    REPTIL, MAMIFERO, PEIXE
}
